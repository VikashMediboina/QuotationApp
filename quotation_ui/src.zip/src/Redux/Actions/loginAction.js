import {SET_TOKEN} from "../type"


export const setToken =(token)=>( {type:SET_TOKEN,token:token})