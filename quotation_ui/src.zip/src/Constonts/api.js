const devURL= "https://backend.com"


export const LOGIN_URL=devURL+"/signin"
export const SIGNUP_URL=devURL+"/signup"